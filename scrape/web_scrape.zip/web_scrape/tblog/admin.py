from django.contrib import admin
from .models import AreaData, StoreData

admin.site.register(AreaData)
admin.site.register(StoreData)