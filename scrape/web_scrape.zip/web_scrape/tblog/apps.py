from django.apps import AppConfig


class TblogConfig(AppConfig):
    name = 'tblog'
