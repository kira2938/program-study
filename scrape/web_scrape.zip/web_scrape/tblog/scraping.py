import os, csv, time, datetime
from selenium import webdriver
from bs4 import BeautifulSoup
import pandas as pd
import numpy as np
from selenium.webdriver.chrome.options import Options
from scrape_setting import UserSide, BrowserSide


def bs_search():
    page = 1
    while True:
        if len(driver.find_elements_by_class_name(tabe_html.nextpage_id_select())) > 0:
            print("##############################page: {} ##############################".format(page))
            driver.implicitly_wait(10)
            page_source = driver.page_source
            bs = BeautifulSoup(page_source, 'html.parser')

            shop_id = []
            shop_name = []
            area_genre = []
            shop_url = [] 
            shop_rate = [] 
            shop_review_cnt = []
            data_list = [
                shop_id , shop_name, area_genre, shop_url, shop_rate, shop_review_cnt
            ]
            osaki_shop_list = bs.find_all('li', class_='js-rst-cassette-wrap')
            for lists in osaki_shop_list:
                data_id = lists.get('data-rst-id')
                shop_id.append(data_id)

                shop_names = lists.find('a', class_='cpy-rst-name')
                shop_name.append(shop_names.text)

                area_genres = lists.find('span', class_='list-rst__area-genre')
                area_genre.append(area_genres.text)

                shop_urls = lists.find('a', class_='list-rst__rst-name-target')
                href = shop_urls.get('href')
                shop_url.append(href)

                shop_rates = lists.find('span', class_='list-rst__rating-val')
                if shop_rates is None:
                    shop_rate.append('-')
                else:
                    shop_rate.append(shop_rates.text)

                review_count = lists.find('a', class_='list-rst__rvw-count-target')
                if review_count is None:
                    shop_review_cnt.append('-')
                else:
                    shop_review_cnt.append(review_count.text)            

            tabelog_done = pd.DataFrame(data_list)
            #df = df.append(tabelog_done, ignore_index=True)

            print(tabelog_done)

            nextpage = driver.find_element_by_class_name(tabe_html.nextpage_id_select()).get_attribute("href")
            driver.get(nextpage)
            page += 1
            driver.implicitly_wait(10)
            time.sleep(5)
        else:
            print('##################################################Last page##################################################')
            page_source = driver.page_source
            bs = BeautifulSoup(page_source, 'html.parser')

            shop_id = []
            shop_name = []
            area_genre = [] 
            shop_url = [] 
            shop_rate = [] 
            shop_review_cnt = []
            data_list = [
                shop_id , shop_name, area_genre, shop_url, shop_rate, shop_review_cnt
            ]
            osaki_shop_list = bs.find_all('li', class_='js-rst-cassette-wrap')
            for lists in osaki_shop_list:
                data_id = lists.get('data-rst-id')
                shop_id.append(data_id)

                shop_names = lists.find('a', class_='cpy-rst-name')
                shop_name.append(shop_names.text)

                area_genres = lists.find('span', class_='list-rst__area-genre')
                area_genre.append(area_genres.text)

                shop_urls = lists.find('a', class_='list-rst__rst-name-target')
                href = shop_urls.get('href')
                shop_url.append(href)

                shop_rates = lists.find('span', class_='list-rst__rating-val')
                if shop_rates is None:
                    shop_rate.append('-')
                else:
                    shop_rate.append(shop_rates.text)

                review_count = lists.find('a', class_='list-rst__rvw-count-target')
                if review_count is None:
                    shop_review_cnt.append('-')
                else:
                    shop_review_cnt.append(review_count.text)

            tabelog_done = pd.DataFrame(data_list)
            #df = df.append(tabelog_done, ignore_index=True)

            print(tabelog_done)
            break
            
        data_list_n = np.array(tabelog_done)        
        writer.writerows(data_list_n.T)
            
    data_list_n = np.array(tabelog_done)        
    writer.writerows(data_list_n.T)

    return bs_search

# ブラウザを立ち上がらないように設定
browser_path = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
chromedriver_path = r'C:\Users\study\Desktop\chromedriver_win32\chromedriver.exe' 
options = Options()
options.binary_location = browser_path # chromeのパスを指定
#options.add_argument('--headless') # ヘッドレスモードを有効にする（コメントアウトするとブラウザ表示）
driver = webdriver.Chrome(chrome_options = options, executable_path=chromedriver_path) # webdriverのパス指定

# サーバーに負担をかけないように待機 implicitly_wait(秒)
driver.implicitly_wait(5)

# UserSide("食べログURL", "検索するエリア", "検索するキーワード", "csvのファイル名(エリアを英語で)") 
# 編集するところはエリアとキーワード、csvファイル名
tabe_input = UserSide("https://tabelog.com/", '大崎', 'osaki')

# 編集するところは "ui-id-6", "ui-id-14"
# エリア、キーワードを入力するとリストが表示され、そのリストから検索したいエリア（キーワード）を選択する
# エリアのリストは"ui-id-3"が一番上にくる
# キーワードのリストは"ui-id-13"が一番上にくる
tabe_html = BrowserSide("sa", '//*[@id="rstsearch_form"]/div/div[5]/div/ul/li[4]', "js-global-search-btn", "c-pagination__arrow--next")


def auto_start(self):
    
    # ブラウザでページを開く
    self.driver.get(self.tabe_input.base_url())
    
    
    #############################地域#############################
    # 検索地域入力欄に指定したキーワード入力
    elem = driver.find_element_by_id(tabe_html.area_input_select())
    elem.clear()
    elem.send_keys(tabe_input.search_area())
    
    # ドロップダウンリストから選んで選択
    elem = driver.find_element_by_xpath(tabe_html.area_class_select())
    elem.click()
    ##############################################################
    
    ########################キーワード#############################
    # 検索地域入力欄に指定したキーワード入力
    #elem = driver.find_element_by_id(tabe_html.key_input_select())
    #elem.clear()
    #elem.send_keys(tabe_input.search_keyword())
    
    # ドロップダウンリストから選んで選択
    #elem = driver.find_element_by_id(tabe_html.key_id_select())
    #elem.click()
    ##############################################################
    
    # 検索ボタンをクリック
    elem = driver.find_element_by_id(tabe_html.search_id_select())
    elem.click()
    
    driver.implicitly_wait(10)

#本日の日付
now = datetime.datetime.now()
#ファイルの存在をチェック
#ファイルがない場合(False)スクレイピングしてファイル作成&保存
if(os.path.isfile(r'C:\Users\study\python_study\tabelog_' + tabe_input.output_csv() + '_{0:%Y%m%d}.csv'.format(now)) == False):

    with open(r'C:\Users\study\desktop\tabelog_' + tabe_input.output_csv() + '_{0:%Y%m%d}.csv'.format(now), 'w', encoding='utf_8_sig') as f:
        header =['id', '店舗名', 'エリア/ジャンル', '店舗URL', '評価点', '口コミ数']
        writer = csv.writer(f, lineterminator='\n')
        writer.writerow(header)

        bs_search()
#ファイルがある場合(True)、プリントする
else:
    print('ファイルが存在します')
    pass
time.sleep(5)

print("DONE")