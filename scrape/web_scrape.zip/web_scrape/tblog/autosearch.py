from selenium import webdriver
from selenium.webdriver.chrome.options import Options



def auto_start():        
    
    # ブラウザを立ち上がらないように設定
    browser_path = "C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"
    chromedriver_path = r'C:\Users\study\Desktop\chromedriver_win32\chromedriver.exe' 
    options = Options()
    options.binary_location = browser_path # chromeのパスを指定
    #options.add_argument('--headless') # ヘッドレスモードを有効にする（コメントアウトするとブラウザ表示）
    driver = webdriver.Chrome(chrome_options = options, executable_path=chromedriver_path) # webdriverのパス指定
    
    # サーバーに負担をかけないように待機 implicitly_wait(秒)
    driver.implicitly_wait(5)
    
    # UserSide("食べログURL", "検索するエリア", "検索するキーワード", "csvのファイル名(エリアを英語で)") 
    # 編集するところはエリアとキーワード、csvファイル名
    
    
    url = "https://tabelog.com/"
    area1 = '大崎'
    area2 = '//*[@id="rstsearch_form"]/div/div[5]/div/ul/li[4]'
    search = "js-global-search-btn"
    #next_page = "c-pagination__arrow--next"
    
    #tabe_input = UserSide("https://tabelog.com/", area1, area2)
    
    # 編集するところは "ui-id-6", "ui-id-14"
    # エリア、キーワードを入力するとリストが表示され、そのリストから検索したいエリア（キーワード）を選択する
    # エリアのリストは"ui-id-3"が一番上にくる
    # キーワードのリストは"ui-id-13"が一番上にくる
    
    
    # ブラウザでページを開く
    driver.get(url)
    
    
    #############################地域#############################
    # 検索地域入力欄に指定したキーワード入力
    elem = driver.find_element_by_id('sa')
    elem.clear()
    elem.send_keys(area1)
    
    # ドロップダウンリストから選んで選択
    elem = driver.find_element_by_xpath(area2)
    elem.click()
    ##############################################################
    
    ########################キーワード#############################
    # 検索地域入力欄に指定したキーワード入力
    #elem = driver.find_element_by_id(tabe_html.key_input_select())
    #elem.clear()
    #elem.send_keys(tabe_input.search_keyword())
    
    # ドロップダウンリストから選んで選択
    #elem = driver.find_element_by_id(tabe_html.key_id_select())
    #elem.click()
    ##############################################################
    
    # 検索ボタンをクリック
    elem = driver.find_element_by_id(search)
    elem.click()
    
    page = 1
    while True:
        if len(driver.find_elements_by_class_name('c-pagination__arrow--next')) > 0:
            print("##############################page: {} ##############################".format(page))
            driver.implicitly_wait(10)

            

            nextpage = driver.find_element_by_class_name('c-pagination__arrow--next').get_attribute("href")
            driver.get(nextpage)
            page += 1
            driver.implicitly_wait(10)
        else:
            print('##################################################Last page##################################################')
            

            print('DONE')
            break

if __name__ == '__main__':
    auto_start()

